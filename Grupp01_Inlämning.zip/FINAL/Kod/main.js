//Webbtjänster - Grupp 1 - Made by Eric Malmström and Anita Olsson

function startTheGame(){
    //sends the players to the pokemon battle web page
    location.href = "./pages/pokemon_cards/pokemoncards.html"
}